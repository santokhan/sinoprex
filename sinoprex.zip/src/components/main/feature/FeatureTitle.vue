<script>
export default { props: ["text"] };
</script>
<template>
  <div class="font-semibold text-3xl xl:text-4xl uppercase text-stone-900">
    {{ text }}
  </div>
</template>
