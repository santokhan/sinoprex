<script>
export default { props: ["src"] };
</script>
<template></template>
