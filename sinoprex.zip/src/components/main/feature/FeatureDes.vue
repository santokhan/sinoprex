<script>
export default { props: ["text"] };
</script>
<template>
  <div class="font-semibold text-stone-500">
    {{ text }}
  </div>
</template>
