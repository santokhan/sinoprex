<script>
export default { props: ["number"] };
</script>

<template>
  <div class="text-gray-500 font-medium text-xl">{{ number }}</div>
</template>
