<script>
export default {
  props: ["src"],
};
</script>
<template>
  <div><img class="w-20" :src="src" alt="card" /></div>
</template>
