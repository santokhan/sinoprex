<script setup>
import Service from "./sevice/Service.vue";
import Achivement from "./achivement/Achivement.vue";
import Team from "./team/Team.vue";
import Portfolio from "./portfolio/Portfolio.vue";
import Quote from "./quote/Quote.vue";
import Review from "./review/Review.vue";
import Blog from "./blog/Blog.vue";
import ReadyToGrow from "./readytogrow/ReadyToGrow.vue";
import Feature from "./feature/Feature.vue";
import FeatureTracking from "./feature/FeatureTracking.vue";
import FeatureTracking2 from "./feature/FeatureTracking2.vue";
import IOT from "./iot/IOT.vue";
import UI from "./ui/UI.vue";
</script>
<template>
  <main>
    <Service></Service>
    <Team></Team>
    <FeatureTracking></FeatureTracking>
    <Feature></Feature>
    <ReadyToGrow></ReadyToGrow>
    <FeatureTracking2 />
    <IOT></IOT>
    <Review></Review>
    <UI></UI>
    <hr />
    <!-- <Portfolio></Portfolio> -->
    <!-- <Blog></Blog> -->
  </main>
</template>
