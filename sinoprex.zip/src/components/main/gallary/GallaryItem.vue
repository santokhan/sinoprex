<template>
  <div class="flex flex-col items-center gap-2">
    <div class="">
      <img
        class="border"
        src="https://plantsbymail.com/wp-content/uploads/2020/11/Alberta-Clipped-Christmas.jpg"
        alt="card"
      />
    </div>
    <div class="text-center">
      <div class="text-gray-800 font-medium">Details</div>
      <div class="text-gray-600 font-medium">27 Dec, 2022</div>
    </div>
  </div>
</template>
