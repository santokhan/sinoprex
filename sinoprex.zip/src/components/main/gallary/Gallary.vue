<script setup>
import GallaryItem from "./GallaryItem.vue";
</script>
<template>
  <div class="max-w-7xl mx-auto py-[8rem] px-4">
    <div
      class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-[2rem]"
    >
      <GallaryItem></GallaryItem>
      <GallaryItem></GallaryItem>
      <GallaryItem></GallaryItem>
      <GallaryItem></GallaryItem>
      <GallaryItem></GallaryItem>
      <GallaryItem></GallaryItem>
      <GallaryItem></GallaryItem>
      <GallaryItem></GallaryItem>
    </div>
  </div>
</template>
