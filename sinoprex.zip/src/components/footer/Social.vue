<template>
  <div
    class="font-medium flex justify-start lg:justify-end gap-2 text-stone-400"
    role="social"
  >
    <div
      class="border h-10 w-10 flex items-center justify-center rounded-full hover:bg-stone-600 hover:border-none"
    >
      <i class="fab fa-facebook" aria-hidden="true"></i>
    </div>
    <div
      class="border h-10 w-10 flex items-center justify-center rounded-full hover:bg-stone-600 hover:border-none"
    >
      <i class="fab fa-twitter" aria-hidden="true"></i>
    </div>
    <div
      class="border h-10 w-10 flex items-center justify-center rounded-full hover:bg-stone-600 hover:border-none"
    >
      <i class="fab fa-linkedin-in"></i>
    </div>
    <div
      class="border h-10 w-10 flex items-center justify-center rounded-full hover:bg-stone-600 hover:border-none"
    >
      <i class="fab fa-instagram" aria-hidden="true"></i>
    </div>
  </div>
</template>
