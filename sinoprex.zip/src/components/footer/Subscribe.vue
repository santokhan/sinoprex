<template>
  <form class="py-[3rem] max-w-[360px]">
    <div
      class="relative border-b border-stone-400 flex justify-between items-center py-2"
    >
      <input
        class="bg-transparent text-white w-full py-2 outline-none border-none"
        type="text"
        placeholder="Enter Your Email Address"
      />
      <i
        class="fab fa-telegram text-xl hover:text-blue-500"
        aria-hidden="true"
      ></i>
    </div>
  </form>
</template>
