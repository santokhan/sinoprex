<template>
  <div
    class="hidden sm:flex items-center gap-[80px] h-8 absolute -right-36 md:-right-32 lg:-right-28 xl:-right-24 top-[50vh] -rotate-90 z-[50]"
  >
    <div>
      <a class="text-white font-medium hover:text-blue-400" href="#">
        <i class="fab fa-facebook text-blue-500" aria-hidden="true"></i>
        <span class="pl-3">Facebook</span>
      </a>
    </div>
    <div>
      <a class="text-white font-medium hover:text-blue-400" href="">
        <i class="fab fa-youtube text-red-600" aria-hidden="true"></i>
        <span class="pl-3">YouTube</span>
      </a>
    </div>
    <div>
      <a class="text-white font-medium hover:text-blue-400" href="">
        <i class="fab fa-twitter text-sky-400" aria-hidden="true"></i>
        <span class="pl-3">Twitter</span>
      </a>
    </div>
  </div>
</template>
