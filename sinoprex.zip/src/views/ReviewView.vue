<script setup>
import Footer from "../components/footer/Footer.vue";
import Header from "../components/header/Header.vue";
import Review from "../components/main/review/Review.vue";
import TopBar from "../components/header/topbar/TopBar.vue";
</script>
<template>
  <TopBar />
  <Review></Review>
  <Footer></Footer>
</template>
