<script setup>
import Header from "../components/header/Header.vue";
import Footer from "../components/footer/Footer.vue";
import TopBar from "../components/header/topbar/TopBar.vue";
</script>

<template>
  <TopBar />
  <Footer></Footer>
</template>
