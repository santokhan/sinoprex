<script setup>
import Header from "../components/header/Header.vue";
import Footer from "../components/footer/Footer.vue";
import Achivement from "../components/main/achivement/Achivement.vue";
import TopBar from "../components/header/topbar/TopBar.vue";
import Gallary from "../components/main/gallary/Gallary.vue";
</script>

<template>
  <TopBar />
  <Achivement></Achivement>
  <Gallary></Gallary>
  <Footer></Footer>
</template>
