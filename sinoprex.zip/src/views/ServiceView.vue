<script setup>
import Header from "../components/header/Header.vue";
import TopBar from "../components/header/topbar/TopBar.vue";
import Footer from "../components/footer/Footer.vue";
import Service from "../components/main/sevice/Service.vue";
</script>

<template>
  <TopBar />
  <Service></Service>
  <Footer></Footer>
</template>
