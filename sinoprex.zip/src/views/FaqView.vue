<script setup>
import Header from "../components/header/Header.vue";
import Footer from "../components/footer/Footer.vue";
import FAQ from "../components/main/faq/FAQ.vue";
import TopBar from "../components/header/topbar/TopBar.vue";
</script>

<template>
  <TopBar />
  <FAQ></FAQ>
  <Footer></Footer>
</template>
